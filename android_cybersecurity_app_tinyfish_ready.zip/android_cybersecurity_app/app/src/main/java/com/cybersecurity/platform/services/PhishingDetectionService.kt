package com.cybersecurity.platform.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.google.android.gms.safetynet.SafetyNet
import com.google.android.gms.safetynet.SafeBrowsingThreat

class PhishingDetectionService : Service() {

    companion object {
        private const val TAG = "PhishingDetection"
        // 🔥 To use this, you need a valid API key from Google Cloud Console
        private const val GOOGLE_SAFE_BROWSING_API_KEY = "YOUR_GOOGLE_CLOUD_API_KEY"

        private val urgentKeywords = mapOf(
            "urgent" to 15, "immediately" to 15, "action required" to 20,
            "verify now" to 20, "security alert" to 18, "suspended" to 20
        )

        private val credentialKeywords = mapOf(
            "password" to 20, "login" to 15, "account" to 10,
            "pin" to 20, "credit card" to 25, "ssn" to 30, "details" to 10
        )

        private val impersonationNames = listOf(
            "bank", "paypal", "google", "microsoft", "apple", "amazon", "netflix"
        )

        private val urlRegex = Regex("""(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\((?:[^\s()<>]+|(?:\([^\s()<>]+\)))*\))+(?:\((?:[^\s()<>]+|(?:\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»Bit.ly“”‘’]))""")

        private val shorteners = listOf(
            "bit.ly", "tinyurl.com", "goo.gl", "t.co", "shorturl", "is.gd"
        )

        private val suspiciousTLDs = listOf(
            ".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top", ".buzz", ".icu", ".pw", ".bid", ".country", ".kim"
        )

        private val trustedDomains = listOf(
            "google.com", "google.co.in", "gemini.google.com", "gemini.com", "openai.com", 
            "chatgpt.com", "microsoft.com", "apple.com", "amazon.in", "amazon.com",
            "paypal.com", "netflix.com", "github.com", "linkedin.com"
        )

        fun analyzeNotification(title: String, message: String): Int {
            val text = "$title $message".lowercase()
            var score = 0

            urgentKeywords.forEach { (word, weight) ->
                if (text.contains(word)) score += weight
            }
            credentialKeywords.forEach { (word, weight) ->
                if (text.contains(word)) score += weight
            }

            if (text.contains("verify") && text.contains("account")) score += 20
            if (text.contains("login") && (text.contains("link") || text.contains("click"))) score += 20

            if (impersonationNames.any { text.contains(it) }) score += 20

            val urls = urlRegex.findAll(text).map { it.value }.toList()
            
            if (urls.isNotEmpty()) {
                score += 10 
                for (url in urls) {
                    val lowerUrl = url.lowercase()
                    val host = lowerUrl.replace("https://", "").replace("http://", "").replace("www.", "").split("/")[0].split("?")[0]

                    if (host.isNotEmpty()) {
                        if (shorteners.any { host == it || host.endsWith(".$it") }) score += 35
                        if (suspiciousTLDs.any { host.endsWith(it) }) score += 40
                        if (trustedDomains.any { host.contains(it) && !host.endsWith(it) }) score += 45
                        
                        val isTrusted = trustedDomains.any { host == it || host.endsWith(".$it") }
                        if (isTrusted) {
                            score -= 80
                        } else {
                            score += 25 
                        }
                    }
                    if (lowerUrl.startsWith("http://")) score += 15
                }
            }

            return score.coerceIn(0, 100)
        }

        /**
         * 🔥 Checks URL against Google Safe Browsing API.
         */
        fun checkGoogleSafeBrowsing(context: Context, url: String, callback: (Boolean) -> Unit) {
            SafetyNet.getClient(context).lookupUri(
                url,
                GOOGLE_SAFE_BROWSING_API_KEY,
                SafeBrowsingThreat.TYPE_POTENTIALLY_HARMFUL_APPLICATION,
                SafeBrowsingThreat.TYPE_SOCIAL_ENGINEERING
            ).addOnSuccessListener { response ->
                if (response.detectedThreats.isEmpty()) {
                    callback(true) // Safe
                } else {
                    Log.w(TAG, "Google Safe Browsing flagged URL: $url")
                    callback(false) // Unsafe
                }
            }.addOnFailureListener { e ->
                Log.e(TAG, "Google Safe Browsing Check Failed: ${e.message}")
                callback(true) // Fallback
            }
        }

        fun describeNotification(title: String, message: String, riskScore: Int): String {
            val isPhishing = riskScore >= 45
            return "Heuristic screening:\nRisk score: $riskScore/100\nAssessment: ${if (isPhishing) "Needs review" else "No strong indicators found"}\nThis score is a screening signal, not proof."
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}


