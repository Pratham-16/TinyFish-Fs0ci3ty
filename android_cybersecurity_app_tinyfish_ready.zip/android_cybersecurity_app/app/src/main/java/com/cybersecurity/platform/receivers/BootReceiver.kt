package com.cybersecurity.platform.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.cybersecurity.platform.AppLogger
import com.cybersecurity.platform.services.AppInstallationMonitor
import com.cybersecurity.platform.services.PhishingDetectionService

class BootReceiver : BroadcastReceiver() {

    companion object {
        const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_BOOT_COMPLETED == intent.action) {
            Log.d(TAG, "Device boot completed, starting security services.")
            AppLogger.log("Device boot detected: starting security services automatically")
            context.startService(Intent(context, AppInstallationMonitor::class.java))
            context.startService(Intent(context, PhishingDetectionService::class.java))
        }
    }
}
