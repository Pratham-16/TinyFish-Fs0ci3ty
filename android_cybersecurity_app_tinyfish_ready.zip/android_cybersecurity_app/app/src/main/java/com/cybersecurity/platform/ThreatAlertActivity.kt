package com.cybersecurity.platform

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import android.widget.Button
import android.util.Log
import android.content.pm.PackageManager

class ThreatAlertActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 🔥 Ensure layout is set first
        setContentView(R.layout.activity_threat_alert)

        // 🔥 Initialize views with safe lookups
        val titleView: TextView? = findViewById(R.id.alertTitle)
        val messageView: TextView? = findViewById(R.id.alertMessage)
        val riskView: TextView? = findViewById(R.id.alertRisk)
        val blockButton: Button? = findViewById(R.id.blockButton)
        val continueButton: Button? = findViewById(R.id.continueButton)

        // 🔥 Extract data safely
        val title = intent.getStringExtra("alert_title") ?: "Threat Detected"
        val message = intent.getStringExtra("alert_message") ?: "Suspicious activity detected."
        val risk = intent.getIntExtra("alert_risk", 0)
        
        // 🚨 Extract actual URL if provided separately, or try to find it in message
        val rawUrl = intent.getStringExtra("alert_url") ?: message

        // 🔥 Update UI
        titleView?.text = title
        messageView?.text = message
        riskView?.text = "Risk Score: $risk%"

        // 🔥 Dynamic color based on risk
        when {
            risk >= 75 -> {
                riskView?.setTextColor(Color.parseColor("#ff4444"))
            }
            risk >= 50 -> {
                riskView?.setTextColor(Color.parseColor("#ffaa00"))
            }
            else -> {
                riskView?.setTextColor(Color.parseColor("#4ade80"))
            }
        }

        // 🚫 BLOCK BUTTON
        blockButton?.setOnClickListener {
            finish()
        }

        // ⚠️ CONTINUE BUTTON
        continueButton?.setOnClickListener {
            try {
                // Find a URL in the content if it's not a direct URL
                val urlToOpen = if (rawUrl.startsWith("http")) {
                    rawUrl
                } else {
                    // Try to extract first URL from text if message was a summary
                    val regex = Regex("(https?://[^\\s]+)")
                    regex.find(rawUrl)?.value ?: ""
                }

                if (urlToOpen.isNotEmpty()) {
                    val uri = Uri.parse(urlToOpen)
                    
                    // 🔥 Strategy: Try Brave Browser specifically
                    val bravePackage = "com.brave.browser"
                    val browserIntent = Intent(Intent.ACTION_VIEW, uri)
                    browserIntent.addCategory(Intent.CATEGORY_BROWSABLE)
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    
                    try {
                        // Check if Brave is installed
                        packageManager.getPackageInfo(bravePackage, 0)
                        browserIntent.setPackage(bravePackage)
                        startActivity(browserIntent)
                    } catch (e: Exception) {
                        // Brave not found, fallback to Chrome
                        val chromePackage = "com.android.chrome"
                        try {
                            packageManager.getPackageInfo(chromePackage, 0)
                            browserIntent.setPackage(chromePackage)
                            startActivity(browserIntent)
                        } catch (ex: Exception) {
                            // Neither Brave nor Chrome found, use chooser but exclude our app
                            browserIntent.setPackage(null)
                            val activities = packageManager.queryIntentActivities(browserIntent, PackageManager.MATCH_DEFAULT_ONLY)
                            val targetIntents = mutableListOf<Intent>()
                            
                            for (ri in activities) {
                                if (ri.activityInfo.packageName != packageName) {
                                    val intent = Intent(browserIntent)
                                    intent.setPackage(ri.activityInfo.packageName)
                                    targetIntents.add(intent)
                                }
                            }
                            
                            if (targetIntents.isNotEmpty()) {
                                val chooser = Intent.createChooser(targetIntents.removeAt(0), "Open Link")
                                if (targetIntents.size > 0) {
                                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetIntents.toTypedArray())
                                }
                                startActivity(chooser)
                            } else {
                                startActivity(Intent.createChooser(browserIntent, "Open with"))
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("ThreatAlert", "Error opening link: ${e.message}")
            }
            finish()
        }
    }
}
