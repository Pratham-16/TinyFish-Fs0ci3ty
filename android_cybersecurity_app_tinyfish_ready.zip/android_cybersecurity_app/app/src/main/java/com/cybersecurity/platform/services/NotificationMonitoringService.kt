package com.cybersecurity.platform.services

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.cybersecurity.platform.AppLogger
import com.cybersecurity.platform.ThreatAlertActivity
import com.cybersecurity.platform.VirusTotalClient

class NotificationMonitoringService : NotificationListenerService() {

    companion object {
        const val TAG = "NotificationMonitoring"
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d(TAG, "Notification Listener Connected")
        AppLogger.log("Notification Monitor: Active and Listening")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName
        if (packageName == "android" || packageName == "com.android.systemui") return

        val notification = sbn.notification
        val extras = notification.extras

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: 
                   extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
        
        val fullContent = "$title $text".trim()
        if (fullContent.isEmpty()) return

        Log.d(TAG, "New Notification from $packageName: $fullContent")
        AppLogger.log("Incoming message from $packageName")

        // 🧠 1. Local AI Phishing Analysis
        val riskScore = PhishingDetectionService.analyzeNotification(title, text)
        val summary = PhishingDetectionService.describeNotification(title, text, riskScore)

        AppLogger.log("Local AI Result: $summary")

        // 🔍 2. VirusTotal Cloud Analysis
        val urlRegex = Regex("""(https?://[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9.-]+\.[a-z]{2,6}/[^\s]*)""")
        val detectedUrl = urlRegex.find(fullContent)?.value ?: ""

        if (detectedUrl.isNotEmpty()) {
            AppLogger.log("Cloud scanning URL: $detectedUrl")
            VirusTotalClient.scanUrl(detectedUrl, object : VirusTotalClient.VTCallback {
                override fun onResult(detected: Int, total: Int, details: String) {
                    AppLogger.log("VirusTotal: $detected/$total engines flagged this.")
                    
                    // Trigger alert if either Local AI or VirusTotal detects threat
                    if (riskScore >= 45 || detected > 0) {
                        val finalSummary = "$summary\n\n☁️ VirusTotal: $detected/$total detections."
                        showThreatAlert("🚨 Phishing Detected", finalSummary, riskScore, detectedUrl)
                    }
                }

                override fun onError(error: String) {
                    Log.e(TAG, "VirusTotal Error: $error")
                    // Fallback to local AI if cloud scan fails
                    if (riskScore >= 45) {
                        showThreatAlert("🚨 Phishing Detected (Local AI)", summary, riskScore, detectedUrl)
                    }
                }
            })
        } else if (riskScore >= 45) {
            // Local AI alert if no URL found but language is suspicious
            showThreatAlert("🚨 Phishing Language Detected", summary, riskScore, "")
        }
    }

    private fun showThreatAlert(title: String, message: String, risk: Int, url: String) {
        try {
            val alertIntent = Intent(this, ThreatAlertActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("alert_title", title)
                putExtra("alert_message", message)
                putExtra("alert_risk", risk)
                putExtra("alert_url", url)
            }
            startActivity(alertIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch alert: ${e.message}")
        }
    }
}
