package com.cybersecurity.platform.services

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.cybersecurity.platform.AppLogger
import com.cybersecurity.platform.SandboxScanner
import com.cybersecurity.platform.ThreatAlertActivity
import com.cybersecurity.platform.VirusTotalClient
import java.io.File

class AppInstallationMonitor : Service() {

    companion object {
        const val TAG = "AppInstallationMonitor"
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action ?: return
            val packageUri = intent.data ?: return
            val packageName = packageUri.schemeSpecificPart ?: return

            if (action == Intent.ACTION_PACKAGE_ADDED || action == Intent.ACTION_PACKAGE_REPLACED) {
                handlePackageInstalled(context, packageName)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(packageReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(packageReceiver, filter)
        }
        
        AppLogger.log("App Install Monitor: Connected to Cloud")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(packageReceiver) } catch (e: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun handlePackageInstalled(context: Context, packageName: String) {
        AppLogger.log("New installation detected: $packageName")
        
        thread {
            try {
                Thread.sleep(3000) // Wait for system to settle
                val appInfo = packageManager.getApplicationInfo(packageName, 0)
                
                // 1. Perform Local Sandbox Scan
                val localResult = SandboxScanner.safeAppScan(packageManager, appInfo)
                AppLogger.log("Local analysis finished for $packageName")

                // 2. Perform VirusTotal Cloud Scan (using APK file hash)
                val apkFile = File(appInfo.sourceDir)
                VirusTotalClient.scanFileHash(apkFile, object : VirusTotalClient.VTCallback {
                    override fun onResult(detected: Int, total: Int, details: String) {
                        AppLogger.log("VirusTotal: $detected/$total detections for $packageName")
                        
                        // Combine local + cloud results
                        val finalRisk = if (detected > 0) 100 else localResult.riskScore
                        val cloudDetails = if (detected > 0) 
                            "\n\n☁️ VirusTotal: $detected engines flagged this as malicious!" 
                            else "\n\n☁️ VirusTotal: No known threats found in cloud database."

                        val alertIntent = Intent(context, ThreatAlertActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            putExtra("alert_title", if (detected > 0) "🚨 MALICIOUS APP DETECTED" else "🛡️ App Scan Complete")
                            putExtra("alert_message", localResult.details + cloudDetails)
                            putExtra("alert_risk", finalRisk)
                        }
                        context.startActivity(alertIntent)
                    }

                    override fun onError(error: String) {
                        Log.e(TAG, "VT Error: $error")
                        // Fallback to local scan result
                        val alertIntent = Intent(context, ThreatAlertActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            putExtra("alert_title", "🛡️ App Scanned (Local Only)")
                            putExtra("alert_message", localResult.details)
                            putExtra("alert_risk", localResult.riskScore)
                        }
                        context.startActivity(alertIntent)
                    }
                })
            } catch (ex: Exception) {
                Log.e(TAG, "Scan failed: ${ex.message}")
            }
        }
    }
    
    private fun thread(block: () -> Unit) { Thread(block).start() }
}
