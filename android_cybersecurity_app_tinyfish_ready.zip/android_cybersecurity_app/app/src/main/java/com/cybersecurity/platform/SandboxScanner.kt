package com.cybersecurity.platform

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.util.Log

data class SandboxScanResult(
    val appName: String,
    val packageName: String,
    val riskScore: Int,
    val riskLevel: String,
    val details: String,
    val reasons: List<String>
)

object SandboxScanner {

    private val suspiciousPermissions = listOf(
        "android.permission.SEND_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.RECORD_AUDIO",
        "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.READ_CONTACTS",
        "android.permission.PROCESS_OUTGOING_CALLS"
    )

    fun safeAppScan(packageManager: PackageManager, appInfo: ApplicationInfo): SandboxScanResult {
        val appName = packageManager.getApplicationLabel(appInfo).toString()
        val packageName = appInfo.packageName
        val reasons = mutableListOf<String>()
        var score = 0

        // 🟢 1. Check Permissions (Safe & Fast)
        try {
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            packageInfo.requestedPermissions?.forEach { perm ->
                if (suspiciousPermissions.contains(perm)) {
                    score += 15
                    reasons.add("Sensitive permission: ${perm.split(".").last()}")
                }
            }
        } catch (e: Exception) {
            Log.e("SandboxScanner", "Error reading permissions: ${e.message}")
        }

        // 🟢 2. Metadata Analysis
        if (packageName.contains("spy") || packageName.contains("hack") || packageName.contains("malware")) {
            score += 40
            reasons.add("Suspicious package naming")
        }

        if (appInfo.flags and ApplicationInfo.FLAG_SYSTEM == 0) {
            score += 10
            reasons.add("User-installed application")
        }

        score = score.coerceIn(0, 100)
        val riskLevel = when {
            score >= 75 -> "CRITICAL"
            score >= 50 -> "HIGH"
            score >= 25 -> "MEDIUM"
            else -> "LOW"
        }

        val details = "App: $appName\n" +
                "Package: $packageName\n" +
                "Risk Score: $score%\n" +
                "Risk Level: $riskLevel\n" +
                "Findings: ${if (reasons.isEmpty()) "None" else reasons.joinToString(", ")}"

        return SandboxScanResult(appName, packageName, score, riskLevel, details, reasons)
    }
}
