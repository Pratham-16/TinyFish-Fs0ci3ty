package com.cybersecurity.platform
import android.net.Uri
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

object BackendApi {
    private val jsonType = "application/json; charset=utf-8".toMediaTypeOrNull()
    private val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(100, TimeUnit.SECONDS).writeTimeout(100, TimeUnit.SECONDS)
        .callTimeout(110, TimeUnit.SECONDS).build()
    private fun baseUrl() = BuildConfig.CYBER_BACKEND_URL.trim().trimEnd('/')
    private fun request(path: String): Request.Builder {
        val base = baseUrl()
        require(base.startsWith("https://") || base.startsWith("http://10.0.2.2:")) {
            "Set cyberBackendUrl to your HTTPS backend URL (or the emulator URL for local development)."
        }
        return Request.Builder().url(base + path)
    }
    private fun deliver(call: Call, callback: (JSONObject?, String?) -> Unit) {
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(null, e.message ?: "Could not reach the analysis service.")
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val raw = it.body?.string().orEmpty()
                    val json = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
                    if (it.isSuccessful) callback(json, null)
                    else callback(null, json.optString("error", "Analysis request failed (" + it.code + ")."))
                }
            }
        })
    }
    fun postJson(path: String, body: JSONObject, callback: (JSONObject?, String?) -> Unit) {
        try {
            val req = request(path).post(body.toString().toRequestBody(jsonType)).build()
            deliver(client.newCall(req), callback)
        } catch (e: Exception) { callback(null, e.message ?: "Backend URL is not configured.") }
    }
    fun checkUrl(url: String, callback: (JSONObject?, String?) -> Unit) =
        postJson("/api/v1/urls/reputation", JSONObject().put("url", url), callback)
    fun checkFileHash(hash: String, callback: (JSONObject?, String?) -> Unit) =
        postJson("/api/v1/files/hash", JSONObject().put("sha256", hash), callback)
    fun quickContext(host: String, callback: (JSONObject?, String?) -> Unit) =
        postJson("/api/v1/tinyfish/context", JSONObject().put("host", host), callback)
    fun startResearch(host: String, callback: (JSONObject?, String?) -> Unit) =
        postJson("/api/v1/tinyfish/research/start", JSONObject().put("host", host), callback)
    fun getResearch(runId: String, callback: (JSONObject?, String?) -> Unit) {
        try { deliver(client.newCall(request("/api/v1/tinyfish/research/" + Uri.encode(runId)).get().build()), callback) }
        catch (e: Exception) { callback(null, e.message ?: "Backend URL is not configured.") }
    }
    fun analyzeImage(file: File, callback: (JSONObject?, String?) -> Unit) {
        try {
            val mime = when (file.extension.lowercase()) {
                "png" -> "image/png"
                "webp" -> "image/webp"
                else -> "image/jpeg"
            }.toMediaTypeOrNull()
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("image", file.name, file.asRequestBody(mime)).build()
            deliver(client.newCall(request("/api/v1/images/deepfake").post(body).build()), callback)
        } catch (e: Exception) { callback(null, e.message ?: "Could not prepare the image.") }
    }
}

