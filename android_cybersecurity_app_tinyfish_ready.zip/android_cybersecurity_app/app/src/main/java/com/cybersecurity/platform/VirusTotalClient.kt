package com.cybersecurity.platform
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.security.MessageDigest

object VirusTotalClient {
    interface VTCallback {
        fun onResult(detected: Int, total: Int, details: String)
        fun onError(error: String)
    }

    fun scanUrl(url: String, callback: VTCallback) {
        BackendApi.checkUrl(url) { result, error ->
            if (error != null || result == null) {
                callback.onError(error ?: "URL reputation lookup failed.")
                return@checkUrl
            }
            if (result.optString("status") == "not_found") {
                callback.onResult(0, 0, "No existing VirusTotal record.")
                return@checkUrl
            }
            val stats = result.optJSONObject("stats") ?: return@checkUrl callback.onError("No scan statistics returned.")
            val malicious = stats.optInt("malicious")
            val suspicious = stats.optInt("suspicious")
            val total = malicious + suspicious + stats.optInt("harmless") + stats.optInt("undetected")
            callback.onResult(malicious + suspicious, total, "VirusTotal: " + malicious + " engines flagged this.")
        }
    }

    fun scanFileHash(file: File, callback: VTCallback) {
        val hash = sha256(file) ?: return callback.onError("Could not calculate the file SHA-256.")
        BackendApi.checkFileHash(hash) { result, error ->
            if (error != null || result == null) {
                callback.onError(error ?: "File reputation lookup failed.")
                return@checkFileHash
            }
            if (result.optString("status") == "not_found") {
                callback.onResult(0, 0, result.optString("message", "No existing VirusTotal record."))
                return@checkFileHash
            }
            val stats = result.optJSONObject("stats") ?: return@checkFileHash callback.onError("No scan statistics returned.")
            val malicious = stats.optInt("malicious")
            val suspicious = stats.optInt("suspicious")
            val total = malicious + suspicious + stats.optInt("harmless") + stats.optInt("undetected")
            callback.onResult(malicious + suspicious, total, "VirusTotal: " + malicious + " engines flagged this file.")
        }
    }

    fun sha256(file: File): String? = try {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(16 * 1024)
            var count: Int
            while (input.read(buffer).also { count = it } != -1) digest.update(buffer, 0, count)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: IOException) { null } catch (_: Exception) { null }
}

