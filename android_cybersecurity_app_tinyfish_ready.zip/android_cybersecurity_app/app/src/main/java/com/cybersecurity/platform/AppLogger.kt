package com.cybersecurity.platform

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Collections

object AppLogger {
    // 🔥 Use a synchronized list to prevent ConcurrentModificationException
    private val entries = Collections.synchronizedList(mutableListOf<String>())
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    fun log(message: String) {
        val timestamp = dateFormat.format(Date())
        entries.add("[$timestamp] $message")
    }

    fun getLogs(): String {
        synchronized(entries) {
            return if (entries.isEmpty()) {
                "No logs yet. Start the app or enable monitoring to generate logs."
            } else {
                entries.joinToString("\n\n")
            }
        }
    }

    fun getHumanReadableLogs(): String {
        synchronized(entries) {
            if (entries.isEmpty()) {
                return "No logs yet. Start the app or enable monitoring to generate logs."
            }
            return entries.toList().map { "• $it" }.joinToString("\n\n")
        }
    }

    fun clear() {
        entries.clear()
    }
}
