package com.cybersecurity.platform.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.cybersecurity.platform.AppLogger
import com.cybersecurity.platform.ThreatAlertActivity

class PackageChangeReceiver : BroadcastReceiver() {

    companion object {
        const val TAG = "PackageChangeReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val packageUri = intent.data ?: return
        val packageName = packageUri.schemeSpecificPart ?: return

        if (action == Intent.ACTION_PACKAGE_ADDED || action == Intent.ACTION_PACKAGE_REPLACED) {
            Log.d(TAG, "Package changed: $packageName")
            AppLogger.log("Package changed: $packageName")
            val alertIntent = Intent(context, ThreatAlertActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("alert_title", "New App Installed")
                putExtra("alert_message", "Package $packageName was installed or updated.")
                putExtra("alert_risk", 40)
            }
            context.startActivity(alertIntent)
        }
    }
}
