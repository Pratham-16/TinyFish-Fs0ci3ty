package com.cybersecurity.platform

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.ToggleButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.cybersecurity.platform.services.AppInstallationMonitor
import com.cybersecurity.platform.services.NotificationMonitoringService
import com.cybersecurity.platform.services.PhishingDetectionService
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val FILE_PICKER = 234
    private val IMAGE_PICKER = 235
    private lateinit var statusText: TextView
    private lateinit var toggleButton: ToggleButton
    private lateinit var logsText: TextView
    private lateinit var logsContainer: View
    private lateinit var fileResultText: TextView
    private lateinit var imageResultText: TextView
    private lateinit var researchResultText: TextView
    private var pendingUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.toggleButton)
        logsText = findViewById(R.id.logsText)
        logsContainer = findViewById(R.id.logsContainer)
        fileResultText = findViewById(R.id.fileResultText)
        imageResultText = findViewById(R.id.imageResultText)
        researchResultText = findViewById(R.id.researchResultText)

        toggleButton.setOnCheckedChangeListener { _, checked ->
            if (checked) startMonitoring() else stopMonitoring()
        }
        findViewById<Button>(R.id.selectFileButton).setOnClickListener { pickFile() }
        findViewById<Button>(R.id.selectImageButton).setOnClickListener { pickImage() }
        findViewById<Button>(R.id.sandboxScanButton).setOnClickListener { scanInstalledApps() }
        findViewById<Button>(R.id.quickContextButton).setOnClickListener { runQuickContext() }
        findViewById<Button>(R.id.deepResearchButton).setOnClickListener { startDeepResearch() }
        findViewById<Button>(R.id.showLogsButton).setOnClickListener {
            logsText.text = AppLogger.getHumanReadableLogs()
            logsContainer.visibility = if (logsContainer.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        findViewById<Button>(R.id.clearLogsButton).setOnClickListener {
            AppLogger.clear()
            logsText.text = "No recent events."
        }
        findViewById<Button>(R.id.downloadLogsButton).setOnClickListener { shareLogs() }
        processIncomingUrl(intent?.data)
        updateStatus("Protection is ready")
    }

    override fun onResume() { super.onResume(); syncPermissionStatus() }
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        processIncomingUrl(intent?.data)
    }

    private fun processIncomingUrl(uri: Uri?) {
        if (uri == null) return
        val url = uri.toString()
        intent.data = null
        thread {
            val score = PhishingDetectionService.analyzeNotification("Shared link", url)
            runOnUiThread {
                if (score >= 60) {
                    startActivity(Intent(this, ThreatAlertActivity::class.java)
                        .putExtra("alert_title", "Suspicious link")
                        .putExtra("alert_message", url)
                        .putExtra("alert_risk", score))
                } else {
                    pendingUrl = url
                    findViewById<TextView>(R.id.researchResultText).text =
                        "Link screened locally. Use Quick context or Deep research to gather TinyFish sources."
                    researchResultText.visibility = View.VISIBLE
                    AppLogger.log("Shared link screened locally ($score/100).")
                }
            }
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return enabled?.contains(packageName) == true
    }
    private fun syncPermissionStatus() {
        if (!::toggleButton.isInitialized) return
        val allowed = isNotificationServiceEnabled() && Settings.canDrawOverlays(this)
        if (!allowed && toggleButton.isChecked) toggleButton.isChecked = false
        if (!allowed) updateStatus("Enable the requested permissions to start protection")
    }
    private fun startMonitoring() {
        if (!isNotificationServiceEnabled()) {
            toggleButton.isChecked = false
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toggleButton.isChecked = false
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, NotificationMonitoringService::class.java))
        startService(Intent(this, AppInstallationMonitor::class.java))
        startService(Intent(this, PhishingDetectionService::class.java))
        updateStatus("Protection monitoring is active")
        AppLogger.log("Security monitoring started.")
    }
    private fun stopMonitoring() {
        stopService(Intent(this, NotificationMonitoringService::class.java))
        stopService(Intent(this, AppInstallationMonitor::class.java))
        stopService(Intent(this, PhishingDetectionService::class.java))
        updateStatus("Monitoring is paused")
        AppLogger.log("Security monitoring paused.")
    }
    private fun updateStatus(message: String) { statusText.text = message }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, FILE_PICKER)
    }
    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(i, IMAGE_PICKER)
    }
    @Deprecated("Using document picker for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != Activity.RESULT_OK) return
        if (requestCode == FILE_PICKER) analyzeFile(uri)
        if (requestCode == IMAGE_PICKER) confirmAndAnalyzeImage(uri)
    }

    private fun analyzeFile(uri: Uri) {
        fileResultText.text = "Reading selected file..."
        thread {
            try {
                val file = copyToCache(uri, 100L * 1024L * 1024L)
                val digest = sha256(file)
                val magic = detectType(file)
                runOnUiThread {
                    fileResultText.text = "Local checks complete\nType signature: $magic\nSHA-256: $digest\nChecking reputation by hash..."
                }
                if (file.extension.equals("apk", true) || magic == "Android package") {
                    runOnUiThread { fileResultText.append("\nAPK detected; checking its hash against VirusTotal. The file is not uploaded.") }
                }
                BackendApi.checkFileHash(digest) { json, error ->
                    runOnUiThread {
                        fileResultText.text = if (error != null) {
                            "Local checks complete\nType signature: $magic\nSHA-256: $digest\nReputation lookup unavailable: $error\nThe file itself was not uploaded."
                        } else {
                            val stats = json?.optJSONObject("stats")
                            val malicious = stats?.optInt("malicious", 0) ?: 0
                            val suspicious = stats?.optInt("suspicious", 0) ?: 0
                            "File analysis\nSignature: $magic\nSHA-256: $digest\nVirusTotal: $malicious malicious, $suspicious suspicious detections\nOnly the hash was checked; the file was not uploaded."
                        }
                        AppLogger.log("File hash analysis finished: " + file.name)
                    }
                }
                file.delete()
            } catch (e: Exception) {
                runOnUiThread { fileResultText.text = "File analysis failed: " + (e.message ?: "Could not read file.") }
            }
        }
    }

    private fun confirmAndAnalyzeImage(uri: Uri) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Send image for screening?")
            .setMessage("The selected image will be sent to your configured inference provider for an experimental AI deepfake screen. Do not use this as proof of authenticity.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ -> analyzeImage(uri) }
            .show()
    }
    private fun analyzeImage(uri: Uri) {
        imageResultText.text = "Preparing image..."
        thread {
            try {
                val file = copyToCache(uri, 8L * 1024L * 1024L, imageExtension(uri))
                runOnUiThread { imageResultText.text = "Analyzing image (experimental)..." }
                BackendApi.analyzeImage(file) { json, error ->
                    runOnUiThread {
                        imageResultText.text = if (error != null) "Image screening unavailable: $error" else {
                            val label = json?.optString("predictedLabel", "unknown")
                            val score = json?.optDouble("confidence", 0.0) ?: 0.0
                            val confidence = String.format("%.1f", score * 100)
                            "Model signal: $label ($confidence% score)\nExperimental screening only. New image generators and edits may evade detection; verify with independent evidence."
                        }
                    }
                    file.delete()
                }
            } catch (e: Exception) {
                runOnUiThread { imageResultText.text = "Could not read image: " + (e.message ?: "unknown error") }
            }
        }
    }

    private fun runQuickContext() {
        val host = targetHost()
        if (host == null) { researchResultText.text = "Enter or share a domain to research."; return }
        researchResultText.text = "TinyFish is searching trusted security sources..."
        BackendApi.quickContext(host) { json, error ->
            runOnUiThread {
                researchResultText.text = if (error != null) "TinyFish context lookup failed: $error" else {
                    val items = json?.optJSONArray("sources")
                    buildString {
                        append("TinyFish quick context for ").append(host).append("\n")
                        if (items == null || items.length() == 0) append("No trusted sources found.")
                        else for (i in 0 until minOf(items.length(), 3)) {
                            val item = items.getJSONObject(i)
                            append("\n\n").append(item.optString("title")).append("\n")
                                .append(item.optString("snippet")).append("\n").append(item.optString("url"))
                        }
                        append("\n\nContext only; this is not a safety verdict.")
                    }
                }
            }
        }
    }
    private fun startDeepResearch() {
        val host = targetHost()
        if (host == null) { researchResultText.text = "Enter or share a domain to research."; return }
        researchResultText.text = "TinyFish is starting multi-source research..."
        BackendApi.startResearch(host) { json, error ->
            if (error != null) runOnUiThread { researchResultText.text = "Research could not start: $error" }
            else {
                val id = json?.optString("researchRunId").orEmpty()
                runOnUiThread { researchResultText.text = "TinyFish research started. Collecting and evaluating cited sources..." }
                if (id.isNotBlank()) pollResearch(id, 0)
            }
        }
    }
    private fun pollResearch(id: String, attempt: Int) {
        if (attempt >= 30) {
            runOnUiThread { researchResultText.append("\nResearch is taking longer. Try again shortly.") }
            return
        }
        BackendApi.getResearch(id) { json, error ->
            if (error != null) {
                runOnUiThread { researchResultText.text = "Research status unavailable: $error" }
            } else {
                val state = json?.optString("status", "").orEmpty()
                val report = json?.optString("report").orEmpty()
                if (report.isNotBlank() || state.equals("completed", true) || state.equals("succeeded", true)) {
                    runOnUiThread {
                        researchResultText.text = "TinyFish cited research\n" +
                            (report.ifBlank { json?.toString(2).orEmpty() }) +
                            "\n\nReview sources before acting; research text is context, not a verdict."
                    }
                } else {
                    runOnUiThread { researchResultText.text = "TinyFish research: " + state.ifBlank { "in progress" } + "..." }
                    android.os.Handler(mainLooper).postDelayed({ pollResearch(id, attempt + 1) }, 5000)
                }
            }
        }
    }
    private fun targetHost(): String? {
        val input = findViewById<TextView>(R.id.indicatorInput).text.toString().trim()
        val raw = input.ifBlank { pendingUrl.orEmpty() }
        if (raw.isBlank()) return null
        return try {
            val normalized = if (raw.contains("://")) raw else "https://$raw"
            Uri.parse(normalized).host?.lowercase()?.removePrefix("www.")
        } catch (_: Exception) { null }
    }

    private fun imageExtension(uri: Uri): String = when (contentResolver.getType(uri)?.lowercase()) {
        "image/png" -> "png"
        "image/webp" -> "webp"
        else -> "jpg"
    }
    private fun copyToCache(uri: Uri, maxBytes: Long, suffix: String = "bin"): File {
        val input = contentResolver.openInputStream(uri) ?: error("Cannot open selected file")
        val file = File.createTempFile("analysis_", ".$suffix", cacheDir)
        input.use { ins ->
            FileOutputStream(file).use { out ->
                val buffer = ByteArray(8192)
                var total = 0L
                while (true) {
                    val n = ins.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= maxBytes) { "File exceeds the allowed size." }
                    out.write(buffer, 0, n)
                }
            }
        }
        return file
    }
    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
    private fun detectType(file: File): String {
        val bytes = ByteArray(8)
        file.inputStream().use { it.read(bytes) }
        return when {
            bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte() -> "ZIP / package archive"
            bytes[0] == 0x7f.toByte() && bytes[1] == 0x45.toByte() -> "Executable (ELF)"
            bytes[0] == 0x4d.toByte() && bytes[1] == 0x5a.toByte() -> "Windows executable (MZ)"
            bytes[0] == 0xff.toByte() && bytes[1] == 0xd8.toByte() -> "JPEG image"
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() -> "PNG image"
            else -> "Unknown / generic data"
        }
    }
    private fun scanInstalledApps() {
        statusText.text = "Reviewing installed apps..."
        thread {
            val apps = packageManager.getInstalledApplications(0)
            var flagged = 0
            apps.forEach { app ->
                val result = SandboxScanner.safeAppScan(packageManager, app)
                if (result.riskScore >= 50) {
                    flagged++
                    AppLogger.log("Review suggested: " + result.appName + " (" + result.riskScore + ")")
                }
            }
            runOnUiThread {
                updateStatus("Installed-app review complete � $flagged flagged for review")
                logsText.text = AppLogger.getHumanReadableLogs()
            }
        }
    }
    private fun shareLogs() {
        try {
            val file = File(getExternalFilesDir(null), "security_events.txt")
            file.writeText(AppLogger.getHumanReadableLogs())
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
            val share = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(share, "Export security events"))
        } catch (e: Exception) { Toast.makeText(this, "Could not export logs", Toast.LENGTH_SHORT).show() }
    }
}





