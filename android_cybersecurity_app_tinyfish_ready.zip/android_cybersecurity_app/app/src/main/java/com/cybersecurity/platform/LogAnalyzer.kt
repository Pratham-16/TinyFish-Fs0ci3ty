package com.cybersecurity.platform

object LogAnalyzer {

    fun summarize(logs: String): String {
        if (logs.isBlank()) {
            return "No logs available to summarize."
        }

        val lines = logs.split("\n\n")
        var scans = 0
        var alerts = 0
        var notifications = 0
        var apks = 0

        lines.forEach { line ->
            if (line.contains("Sandbox scan result", ignoreCase = true) || line.contains("Sandbox scanning", ignoreCase = true)) scans++
            if (line.contains("Suspicious notification", ignoreCase = true) || line.contains("risk ", ignoreCase = true) && line.contains("notification", ignoreCase = true)) notifications++
            if (line.contains("APK", ignoreCase = true)) apks++
            if (line.contains("Threat Alert", ignoreCase = true) || line.contains("alert", ignoreCase = true)) alerts++
        }

        return buildString {
            append("Log summary:\n")
            append("- Total entries: ${lines.size}\n")
            append("- App scans: $scans\n")
            append("- Notification checks: $notifications\n")
            append("- APK pre-install scans: $apks\n")
            append("- Alerts generated: $alerts\n")
            append("\nFull log details are available in the log viewer.")
        }
    }
}
