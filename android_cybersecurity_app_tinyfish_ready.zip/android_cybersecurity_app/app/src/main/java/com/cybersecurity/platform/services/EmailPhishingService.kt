package com.cybersecurity.platform.services

import kotlin.math.min

object EmailPhishingService {

    private val urgentKeywords = mapOf(
        "urgent" to 15, "immediately" to 15, "action required" to 20,
        "verify now" to 20, "security alert" to 18
    )

    private val credentialKeywords = mapOf(
        "password" to 20, "login" to 15, "account" to 10,
        "pin" to 20, "credit card" to 25
    )

    private val trustedDomains = listOf(
        "google.com", "amazon.com", "amazon.in",
        "microsoft.com", "apple.com", "paypal.com"
    )

    private val impersonationBrands = listOf(
        "google", "amazon", "paypal", "microsoft", "apple", "bank"
    )

    private val urlRegex = Regex("https?://[\\w.-]+(?:\\.[\\w.-]+)+[/#?]?.*")

    fun analyzeEmail(sender: String, subject: String, body: String): Int {

        val text = "$subject $body".lowercase()
        var score = 0

        urgentKeywords.forEach { (word, weight) ->
            if (text.contains(word)) score += weight
        }

        credentialKeywords.forEach { (word, weight) ->
            if (text.contains(word)) score += weight
        }

        if (text.contains("verify") && text.contains("account")) score += 15
        if (text.contains("login") && text.contains("urgent")) score += 15
        if (text.contains("click") && text.contains("link")) score += 15

        val domain = if (sender.contains("@")) {
            sender.substringAfter("@").lowercase()
        } else ""

        val isTrusted = trustedDomains.any { domain.contains(it) }

        if (!isTrusted) {
            score += 20

            if (domain.length > 25 || domain.count { it.isDigit() } > 3) {
                score += 10
            }
        }

        if (impersonationBrands.any { text.contains(it) } && !isTrusted) {
            score += 20
        }

        val urls = urlRegex.findAll(text).map { it.value }.toList()

        for (url in urls) {
            val lowerUrl = url.lowercase()

            if (lowerUrl.contains("bit.ly") || lowerUrl.contains("tinyurl")) {
                score += 25
            }

            if (lowerUrl.startsWith("http://")) {
                score += 15
            }

            if (Regex("https?://\\d+\\.\\d+\\.\\d+\\.\\d+").containsMatchIn(lowerUrl)) {
                score += 25
            }

            val trusted = trustedDomains.any { lowerUrl.contains(it) }
            if (!trusted) {
                score += 15
            }
        }

        if (text.contains("account suspended")) score += 25
        if (text.contains("unauthorized access")) score += 25
        if (text.contains("password reset")) score += 20

        return min(score, 100)
    }

    fun generateReport(sender: String, subject: String, body: String, riskScore: Int): String {

        val text = "$subject $body".lowercase()
        val findings = mutableListOf<String>()

        if (urgentKeywords.keys.any { text.contains(it) }) findings.add("urgent language")
        if (credentialKeywords.keys.any { text.contains(it) }) findings.add("credential request")

        val domain = if (sender.contains("@")) {
            sender.substringAfter("@").lowercase()
        } else ""

        if (!trustedDomains.any { domain.contains(it) }) {
            findings.add("untrusted sender domain")
        }

        if (impersonationBrands.any { text.contains(it) }) {
            findings.add("possible brand impersonation")
        }

        val urls = urlRegex.findAll(text).map { it.value }.toList()
        if (urls.isNotEmpty()) findings.add("contains links")

        val result = if (findings.isEmpty()) {
            "No strong phishing indicators detected."
        } else {
            findings.distinct().joinToString(", ")
        }

        return """
            📧 AI Email Phishing Analysis
            
            Sender: $sender
            Subject: $subject
            
            Risk Score: $riskScore%
            
            Detected Signals: $result
        """.trimIndent()
    }
}