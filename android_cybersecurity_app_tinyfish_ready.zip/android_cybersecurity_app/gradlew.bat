@echo off
setlocal
set "DIR=%~dp0"
"%DIR%gradle-8.2\bin\gradle.bat" %*
