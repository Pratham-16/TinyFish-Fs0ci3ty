# Aegis Cybersecurity Platform

Android phishing and file triage with a server-side TinyFish research workflow.

## Start the backend

1. Install Node.js 20 or later.
2. In `backend/`, copy `.env.example` to `.env`.
3. Add `TINYFISH_API_KEY`, `VIRUSTOTAL_API_KEY`, and `HF_TOKEN` to `backend/.env`.
4. Run `npm install`, then `npm start`.

The TinyFish key is read only by `backend/server.js`. Do not add it to Kotlin, `BuildConfig`, Android resources, or the APK. Never commit `backend/.env`.

## Point Android at the backend

For the Android emulator, use `-PcyberBackendUrl=http://10.0.2.2:8080`. For a phone or release build, use an HTTPS backend URL, for example `-PcyberBackendUrl=https://your-api.example`.

## What the analysis buttons do

- **File analysis** calculates SHA-256 locally and checks that hash with VirusTotal. The file itself is not uploaded.
- **Image authenticity screening** sends a user-selected image to the configured Hugging Face image-classification model through the backend. This is an experimental classifier, not proof that an image is real or fake.
- **Quick web context** uses TinyFish Search to find public cybersecurity sources and TinyFish Fetch to extract the selected source pages.
- **Deep research** starts a TinyFish cited research run. It can take several minutes; the dashboard checks the run periodically and shows the cited report when ready.

The TinyFish request uses `weak_sources_enabled=false`. The current implementation searches and fetches trusted public security publisher domains for quick context. The deep research query asks TinyFish to use multiple sources and distinguish evidence from inference.

## API keys

- `TINYFISH_API_KEY`: TinyFish Dashboard API key, stored in `backend/.env`.
- `VIRUSTOTAL_API_KEY`: VirusTotal key, stored in `backend/.env`.
- `HF_TOKEN`: Hugging Face token with Inference Providers access, stored in `backend/.env`.

The project archive included a VirusTotal key directly in Android source. Revoke that key and create a replacement before using the backend. Check Git history as well.

